=== Store Map ===
Contributors:      10up
Donate link:       
Tags: 
Requires at least: 4.1
Tested up to:      4.1
Stable tag:        0.1.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

Simple liste of store on the map

== Description ==



== Installation ==

= Manual Installation =

1. Upload the entire `/store-map` directory to the `/wp-content/plugins/` directory.
2. Activate Store Map through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release
